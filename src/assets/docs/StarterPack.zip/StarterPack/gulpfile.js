// gulpfile.js (CommonJS version)
const gulp = require("gulp");
const sass = require("gulp-sass")(require("sass"));
const browserSync = require("browser-sync").create();
const del = require("del");

// Paths
const paths = {
  scss: {
    src: "src/styles/**/*.scss",
    dest: "dist/css",
  },
  html: {
    src: "src/**/*.html",
    dest: "dist",
  },
  js: {
    src: "src/scripts/**/*.js",
    dest: "dist/js",
  },
};

// Clean
function clean() {
  return del(["dist"]);
}

// Styles
function styles() {
  return gulp
    .src(paths.scss.src)
    .pipe(sass().on("error", sass.logError))
    .pipe(gulp.dest(paths.scss.dest))
    .pipe(browserSync.stream());
}

// HTML
function html() {
  return gulp
    .src(paths.html.src)
    .pipe(gulp.dest(paths.html.dest))
    .pipe(browserSync.stream());
}

// Scripts
function scripts() {
  return gulp
    .src(paths.js.src)
    .pipe(gulp.dest(paths.js.dest))
    .pipe(browserSync.stream());
}

// Watch + serve
function serve() {
  browserSync.init({
    server: "./dist",
  });
  gulp.watch(paths.scss.src, styles);
  gulp.watch(paths.html.src, html);
  gulp.watch(paths.js.src, scripts);
}

// Tasks
exports.clean = clean;
exports.styles = styles;
exports.html = html;
exports.scripts = scripts;
exports.serve = serve;

exports.default = gulp.series(
  clean,
  gulp.parallel(styles, html, scripts),
  serve
);
